``` ini

BenchmarkDotNet=v0.11.4, OS=Windows 10.0.19042
Intel Core i5-10310U CPU 1.70GHz, 1 CPU, 8 logical and 4 physical cores
.NET Core SDK=2.2.207
  [Host]     : .NET Core 2.2.8 (CoreCLR 4.6.28207.03, CoreFX 4.6.28208.02), 32bit RyuJIT
  DefaultJob : .NET Core 2.2.8 (CoreCLR 4.6.28207.03, CoreFX 4.6.28208.02), 32bit RyuJIT


```
|                         Method | IterationCount |        Mean |       Error |      StdDev |      Median |
|------------------------------- |--------------- |------------:|------------:|------------:|------------:|
|       **RestGetSmallPayloadAsync** |            **100** |    **23.99 ms** |   **2.4501 ms** |   **7.1081 ms** |    **22.08 ms** |
|       RestGetLargePayloadAsync |            100 | 1,766.55 ms |  94.7045 ms | 274.7549 ms | 1,728.65 ms |
|      RestPostLargePayloadAsync |            100 | 2,691.21 ms |  77.3372 ms | 220.6473 ms | 2,631.28 ms |
|       GrpcGetSmallPayloadAsync |            100 |    19.47 ms |   0.3840 ms |   0.8184 ms |    19.39 ms |
|    GrpcStreamLargePayloadAsync |            100 | 3,754.88 ms |  72.1742 ms | 193.8912 ms | 3,721.00 ms |
| GrpcGetLargePayloadAsListAsync |            100 |   156.73 ms |   3.2352 ms |   9.1776 ms |   157.20 ms |
|      GrpcPostLargePayloadAsync |            100 |   158.30 ms |   3.1560 ms |   8.8498 ms |   158.54 ms |
|       **RestGetSmallPayloadAsync** |            **200** |    **40.32 ms** |   **1.7277 ms** |   **4.9572 ms** |    **38.54 ms** |
|       RestGetLargePayloadAsync |            200 | 2,706.00 ms |  54.0257 ms | 137.5127 ms | 2,706.48 ms |
|      RestPostLargePayloadAsync |            200 | 4,041.80 ms | 184.8423 ms | 545.0118 ms | 4,028.46 ms |
|       GrpcGetSmallPayloadAsync |            200 |    28.55 ms |   0.3212 ms |   0.2847 ms |    28.59 ms |
|    GrpcStreamLargePayloadAsync |            200 | 5,185.97 ms | 101.3369 ms | 182.7314 ms | 5,172.12 ms |
| GrpcGetLargePayloadAsListAsync |            200 |   201.47 ms |   3.9612 ms |   3.7053 ms |   201.47 ms |
|      GrpcPostLargePayloadAsync |            200 |   206.02 ms |   4.0764 ms |   7.8539 ms |   206.20 ms |
